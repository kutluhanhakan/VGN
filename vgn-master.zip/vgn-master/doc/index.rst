.. _index:

Welcome to VGN's documentation!
*******************************

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   references/functions
   references/data_classes
   references/exceptions
