Exceptions
==========

.. automodule:: vgn.exceptions
   :members:
