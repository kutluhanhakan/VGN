Data Classes
============

.. automodule:: vgn.data_classes
   :members:
